============
  SimplIC3
============

:author: Alberto Griggio <griggio@fbk.eu>


OVERVIEW
--------

SimplIC3 a "simple" implementation of IC3 (and other SAT-based model checking
algorithms like BMC and K-Induction) for finite-state functional transition
systems (currently it supports only the Aiger format as input).


CREDITS
-------

The tool has been implemented from scratch, but it uses/borrows (i.e. steals
:-) ideas from several publications and state-of-the-art tools. See the
CREDITS.txt file for the relevant information. If you think we forgot
somebody, please let us know.


REQUIREMENTS
------------

* A C++ compiler

* The CMake build system 

* At least one SAT solver to be used as a backend. The currently supported
  solvers are::

  - MiniSat >= 2.2.0 (http://www.minisat.se)
  - Picosat >= 953 (http://fmv.jku.at/picosat/)

  For MiniSat 2.2.0, you also need to apply the patch
  minisat_2.2.0_releaseVar.patch provided here, as follows::

    $ cd /path/to/minisat-2.2.0; patch -p1 < minisat_2.2.0_releaseVar.patch


COMPILING
---------

* Compile the selected backend SAT solver(s)

* Create a separate build directory (e.g. a build/ subdir of the source
  tree). Then::

    $ mkdir build/
    $ cd build
    $ cmake .. -DCMAKE_BUILD_TYPE=Release -DENABLE_MINISAT=1 -DMINISAT_SOURCE_DIR=/path/to/minisat -DMINISAT_BUILD_DIR=/dir/of/minisat/library
    $ make

  By default, the MiniSat backend is enabled. PicoSat can be enabled with
  -DENABLE_PICOSAT=1. In this case, you should also use
  -DPICOSAT_SOURCE_DIR=path and -DPICOSAT_BUILD_DIR=path


RUNNING
-------

$ ./simplic3 /path/to/filename.aig

For a list of options, see -h. Example::

$ ./simplic3 -v -s minisat -u 0 -r 1000 -m 1 /path/to/filename.aig


There's also a simple portfolio version of the solver, called
simplic3_par.py. It requires the Python API to be built (see
simplic3_python_setup.py), and runs several engines in parallel (without any
communication among them).
