This is a bugfix release of the version of nuXmv-bitcore submitted to
HWMCC'13. See LICENSE.txt for licensing information, and src/README.txt for
other information.

The differences with the HWMCC'13 version are:

- fixed a bug in the parser affecting files with bad state properties 
  (Aiger >= 1.9)

- fixed a bug in the simulator which significantly reduced the effectiveness
  of temporal decomposition (to the point where it was almost useless)

- fixed generation of inductive invariants with IC3 when using property
  unrolling
